class Complex{

  constructor(r = 0, i = 0){
    this.r = r;
    this.i = i;
  }

}