document.onload = function(){
  initialize();
}

