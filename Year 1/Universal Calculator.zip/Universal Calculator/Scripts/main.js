window.onload = function () {
  initialize();
}

